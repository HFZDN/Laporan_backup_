<?php
require "config.php";
$id = $_GET['id'];//didapat dari url yang telah mengirimkan value id
$sql = "DELETE FROM table_crud WHERE id='$id'";
$execute = mysqli_query($config,$sql);

if($execute){
	header("Location:read.php"); //agar kembali kehalaman read.php secara otomatis
}else {
	echo "Fail to Delete!";
	
}

?>
