<?php
$server = "localhost";  
$username = "root";
$password = "";
$database = "db_crud";

$config = mysqli_connect($server, $username, $password, $database); 

?>

 