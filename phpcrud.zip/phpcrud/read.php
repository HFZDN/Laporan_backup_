<?php 
require "config.php";
$sql = "SELECT  * FROM table_crud";
$execute = mysqli_query($config,$sql); // $config berasal dari koneksi.php yang telah kita hubungkan
$result = mysqli_fetch_assoc($execute);
?>
 
<!DOCTYPE html>
<html>
<head>
	<title>Read PHP</title>
</head>
<body>
	<a href="create.php ">
	<table border="3" color="black" width= "100%" >
		 <thead>
		 	<th>No.IC</th>
		 	<th>Name</th>
		 	<th>Class</th>
		 	<th>Action</th>
		 </thead>
	<?php while ($result = mysqli_fetch_assoc($execute)){ ?>
	
		 <tr>
		 	<td><?= $result['id']?></td>
		 	<td><?= $result['nama']?></td>
		 	<td><?= $result['kelas']?></td>
		 	<td>
		 		<a href="update.php?id=<?= $result['id']?>">Update</a> 

:
		 		<a href="delete.php?id=<?= $result['id']?>">Delete</a>
		 	</td>
		 </tr>
		<?php }?>
	</table>

</body>
</html>
